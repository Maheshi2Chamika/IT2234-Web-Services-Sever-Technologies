let  students = [
    {regNo:"2021ICT10",Name:'Silva',age:25,gender:'F'},
    {regNo:"2021ICT25",Name:'Fernando',age:24,gender:'M'},
    {regNo:"2021ICT89",Name:'Disanayaka',age:26,gender:'F'},
    {regNo:"2021ICT14",Name:'Rathnayaka',age:25,gender:'M'},
    {regNo:"2021ICT32",Name:'Bandara',age:23,gender:'F'}
];

module.exports = students;